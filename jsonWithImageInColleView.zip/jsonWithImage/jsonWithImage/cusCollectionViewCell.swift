//
//  cusCollectionViewCell.swift
//  jsonWithImage
//
//  Created by Mac on 6/19/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class cusCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
}
