//
//  ViewController.swift
//  jsonWithImage
//
//  Created by Mac on 6/19/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIViewContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func downloadedFrom(link: String, contentMode mode: UIViewContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
}



struct jsonParse: Decodable
{
    
    let localized_name:String
    let img:String
    
    
//    let  base_attack_min:String
//    let base_attack_max:String
//    let legs:String
//    let move_speed:String
 
}

class ViewController: UIViewController {

    
    @IBOutlet weak var collView: UICollectionView!
    
    var aryData = [jsonParse]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collView.dataSource = self
        collView.delegate = self
        
        callAPI()
    }
    
    func callAPI()
    {
        let url = URL(string: "https://api.opendota.com/api/heroStats")
        
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            
            guard let data = data else { return }
            
            do {
                self.aryData = try JSONDecoder().decode([jsonParse].self, from: data)
                
            }catch {
                print("Parse Error")
            }
            
            DispatchQueue.main.async
                {
                self.collView.reloadData()
                print(self.aryData.count)
                print(self.aryData)
                }
            }.resume()
        
        }
    }

extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return aryData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cusCell", for: indexPath)as! cusCollectionViewCell
        
        cell.lblName.text = aryData[indexPath.row].localized_name
        
        
        let defaultLink = "https://api.opendota.com"
        let completeLink = defaultLink + aryData[indexPath.row].img
        
        cell.imgView.downloadedFrom(link: completeLink)
        
        cell.imgView.layer.cornerRadius = cell.imgView.frame.height/2
        cell.imgView.clipsToBounds = true
         cell.imgView.contentMode = .scaleAspectFill
        return cell
    }
    
    
}
